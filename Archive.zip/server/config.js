const CONFIG = {
  APP: {
    PORT: 3003,
  },
  DB: {
    HOST: 'www.db4free.net',
    DATABASE: 'petelocation',
    USER: 'prknutson',
    PASSWORD: 'pete1234',
  },
  GOOGLEMAPS: {
    KEY: 'AIzaSyApGWA1NEDnW8jiZq3pTgo7hapY-9VkUwk',
  },
};

module.exports = CONFIG;



// DB: {
//   HOST: 'localhost',
//   DATABASE: 'TripAdvisor_Locations',
//   USER: 'root',
//   PASSWORD: '',
// },